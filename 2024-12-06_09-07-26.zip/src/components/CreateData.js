import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import { ref, set } from "firebase/database";
import { v4 as uuidv4 } from "uuid";
import { useAuth } from "./Auth/AuthContext";
import "react-datepicker/dist/react-datepicker.css";
import { Collapse } from "react-collapse";

const CreateForm = () => {
  const [openSections, setOpenSections] = useState({
    general: true,
  });

  const toggleSection = (section) => {
    setOpenSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const [formData, setFormData] = useState({
    object_title: "",
    object_type: "",
    object_id: "",
    title: "",
    description: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e, field) => {
    setFormData({ ...formData, [field]: e.target.files });
  };

  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (loading) return;

    setLoading(true);

    const recordId = uuidv4();
    const recordRef = ref(db, `objects/${recordId}`);

    try {
      await set(recordRef, formData);
      alert("Record added successfully!");
      setFormData({});
    } catch (error) {
      console.error("Error adding record:", error);
      alert("Failed to add record. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* General Information */}
      <div>
        <button type="button" onClick={() => toggleSection("general")}>
          General Information
        </button>
        <Collapse isOpened={openSections.general}>
          <div>
            <input
              type="text"
              name="object_title"
              placeholder="Object Title"
              value={formData.object_title}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="object_type"
              placeholder="Object Type"
              value={formData.object_type}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="object_id"
              placeholder="Object ID"
              value={formData.object_id}
              onChange={handleInputChange}
            />
            <input
              type="text"
              name="title"
              placeholder="Title"
              value={formData.title}
              onChange={handleInputChange}
            />
            <textarea
              name="description"
              placeholder="Description"
              value={formData.description}
              onChange={handleInputChange}
            />
          </div>
        </Collapse>
      </div>
      {/* Submit Button */}
      <button type="submit" disabled={loading}>Submit</button>
    </form>
  );
};

export default CreateForm;
