// src/components/constants.js
export const objectTypes = [
    "Figure",
    "Coin",
    "Ivory",
    "Jewellery",
    "Sculpture",
    "Pottery",
    "Postcard",
    "Painting",
    "Ceramic",
    "Fabric",
    "Other", // Add more as needed
  ];
  